package com.example.excel;

import cn.hutool.core.io.FileUtil;
import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;

import java.util.List;

/**
 * dzp 2021/9/10
 */
public class Test {

    public void method() {
        ExcelReader reader = ExcelUtil.getReader(FileUtil.file("test.xlsx"));
        List<List<Object>> read = reader.read();

    }



}
